﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Group9OMC
{
    public partial class Medication_Reminder : Form
    {
        public Medication_Reminder()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void ggyug(object sender, EventArgs e)
        {

        }

        private void txtMedicationName_Enter(object sender, EventArgs e)
        {

        }

        private void txtDosage_TextChanged(object sender, EventArgs e)
        {

        }

        private void Medication_Reminder_Load(object sender, EventArgs e)
        {
            dataGridView1.RowTemplate.Height = 45;
            //dataGridView1.Rows.Add(15);

        }

        private void btnSetReminder_Click(object sender, EventArgs e)
        {
            string namaUbat = txtMedicationName.Text;
            string dos = txtDosage.Text;
            string masa = txtTime.Text;
            string frequency = txtFrequent.Text;

            if (string.IsNullOrWhiteSpace(namaUbat) || string.IsNullOrWhiteSpace(dos) ||
                string.IsNullOrWhiteSpace(masa) || string.IsNullOrWhiteSpace(frequency))
            {
                MessageBox.Show("Please enter your medication detail");
                return;
            }

            
            bool Rows = false;
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (row.IsNewRow) continue;

               
                if (row.Cells[0].FormattedValue == null || string.IsNullOrEmpty(row.Cells[0].FormattedValue.ToString().Trim()))
                {
                    row.Cells[0].Value = namaUbat;
                    row.Cells[1].Value = dos;
                    row.Cells[2].Value = masa;
                    row.Cells[3].Value = frequency;
                    Rows = true;
                    break;
                }
            }

            if (!Rows)
            {
                dataGridView1.Rows.Add(namaUbat, dos, masa, frequency);
            }

            
            txtMedicationName.Text = "";
            txtDosage.Text = "";
            txtFrequent.Text = "";
            txtTime.Text = "";

            txtMedicationName.Focus();


        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtMedicationName.Text = " ";
            txtDosage.Text = " ";
            txtFrequent.Text = " ";
            txtTime.Text = " ";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
               
                foreach (DataGridViewRow row in dataGridView1.SelectedRows)
                {
                    if (!row.IsNewRow)
                    {
                        dataGridView1.Rows.Remove(row);
                    }
                }
                MessageBox.Show("Selected medications successfully deleted!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Please click the row header (klik kotak paling kiri sekali untuk pilih satu baris penuh) to delete!", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && !dataGridView1.Rows[e.RowIndex].IsNewRow)
    {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                
                txtMedicationName.Text = row.Cells[0].Value?.ToString();
                txtDosage.Text = row.Cells[1].Value?.ToString();
                txtTime.Text = row.Cells[2].Value?.ToString();
                txtFrequent.Text = row.Cells[3].Value?.ToString();
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please Click the row that you one to edit in schedule first!", "Reminder", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string namaUbat = txtMedicationName.Text;
            string dos = txtDosage.Text;
            string masa = txtTime.Text;
            string frequency = txtFrequent.Text;

            
            if (string.IsNullOrWhiteSpace(namaUbat) || string.IsNullOrWhiteSpace(dos) ||
                string.IsNullOrWhiteSpace(masa) || string.IsNullOrWhiteSpace(frequency))
            {
                MessageBox.Show("Please Make Sure all medication details fill in before updated ", "Reminder", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

           
            selectedRow.Cells[0].Value = namaUbat;
            selectedRow.Cells[1].Value = dos;
            selectedRow.Cells[2].Value = masa;
            selectedRow.Cells[3].Value = frequency;

            MessageBox.Show("Medication detail updated!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            
            txtMedicationName.Text = "";
            txtDosage.Text = "";
            txtTime.Text = "";
            txtFrequent.Text = "";

            txtMedicationName.Focus();
        }
    }
}
    

