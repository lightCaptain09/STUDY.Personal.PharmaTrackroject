﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group9OMC
{
    public partial class Financial_Planning : Form
    {
        public Financial_Planning()
        {
            InitializeComponent();
            txtIncome.Text = "RM";
            txtIncome.ForeColor = System.Drawing.Color.Gray;
            txtBudget.Text = "RM";
            txtBudget.ForeColor = System.Drawing.Color.Gray;
            txtSpent.Text = "RM";
            txtSpent.ForeColor = System.Drawing.Color.Gray;

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

            string incomeInput = txtIncome.Text.Trim();
            string budgetInput = txtBudget.Text.Trim();
            string spentInput = txtSpent.Text.Trim();

            if (string.IsNullOrEmpty(incomeInput) || string.IsNullOrEmpty(budgetInput) || string.IsNullOrEmpty(spentInput))
            {
                MessageBox.Show("Please Enter Your Financial detail First", "Reminder", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            
            if (double.TryParse(incomeInput, out double income) &&
                double.TryParse(budgetInput, out double budget) &&
                double.TryParse(spentInput, out double spent))
            {
               
                double remaining = budget - spent;

                
                lblIncome.Text = $"RM{income:F2}";
                lblBudget.Text = $"RM{budget:F2}";
                lblSpent.Text = $"RM{spent:F2}";
                lblRemaining.Text = $"RM{remaining:F2}";

                
                txtIncome.Clear();
                txtBudget.Clear();
                txtSpent.Clear();

                MessageBox.Show("Finacial Data being Updated!");
            }
            else
            {
                MessageBox.Show("Please Make sure the information are in number Only!", "Reminder", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtIncome_MouseClick(object sender, MouseEventArgs e)
        {
            txtIncome.Clear();
        }

        private void txtBudget_MouseClick(object sender, MouseEventArgs e)
        {
            txtBudget.Clear();
        }

        private void txtSpent_MouseClick(object sender, MouseEventArgs e)
        {
            txtSpent.Clear();
        }
    }
}
