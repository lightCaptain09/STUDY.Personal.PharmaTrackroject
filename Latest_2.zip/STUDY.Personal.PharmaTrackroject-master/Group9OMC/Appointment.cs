﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group9OMC
{
    public partial class Appointment : Form
    {
        private List<AppointmentData> appointmentList = new List<AppointmentData>();
        public Appointment()
        {
            InitializeComponent();
            txtDate.Text = "Please Select date On calendar";
            txtDate.ForeColor = Color.Gray;

        }

        private void btnSetAppointment_Click(object sender, EventArgs e) 
        {
            DateTime AppointDate = monthCalendar1.SelectionStart.Date;

            string timeTxt = txtTimeAppoitn.Text;
            string doctorTxt = cboDoctor.Text;
            string reasonTxt = txtReason.Text;

            if (string.IsNullOrWhiteSpace(timeTxt) || string.IsNullOrWhiteSpace(doctorTxt) || string.IsNullOrWhiteSpace(reasonTxt))
            {
                MessageBox.Show("Please fill in all appointment details first!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            monthCalendar1.AddBoldedDate(AppointDate);
            monthCalendar1.UpdateBoldedDates();

            AppointmentData newAppointment = new AppointmentData
            {
                Date = AppointDate,
                Time = timeTxt,
                Doctor = doctorTxt,
                Reason = reasonTxt
            };
            appointmentList.Add(newAppointment);

            lblUpcomingDate.Text = "Upcoming Appointments";

            flwUpcoming.Controls.Clear();

            int yOffset = 5;

            
            foreach (AppointmentData app in appointmentList)
            {
                
                Panel card = CreateAppointmentCard(app.Time, app.Doctor, app.Reason, app.Date.ToString("dd MMMM yyyy"));

                card.Location = new Point(5, yOffset);
                flwUpcoming.Controls.Add(card);

                yOffset += 120;
            }

            MessageBox.Show("Your Appointment Successfully Set and Marked at calendar!");
        }
        

        private void monthCalendar1_DateSelected(object sender, DateRangeEventArgs e)
        {
            txtDate.Text = e.Start.ToString("dd/MM/yyyy");
            DateTime clickedDate = e.Start.Date;

            
            flwUpcoming.Controls.Clear();
            int appointmentCount = 0;

            
            foreach (AppointmentData app in appointmentList)
            {
                if (app.Date == clickedDate)
                {
                    appointmentCount++;
                    
                    Panel card = CreateAppointmentCard(app.Time, app.Doctor, app.Reason, clickedDate.ToString("dd MMMM yyyy"));
                    flwUpcoming.Controls.Add(card);
                }
            }


            lblUpcomingDate.Text = "Upcoming Appointments";

            if (appointmentCount == 0)
            {
                Label lblNoData = new Label { Text = "No appointments for this date.", AutoSize = true, ForeColor = Color.Gray };
                flwUpcoming.Controls.Add(lblNoData);
            }
        }
        
        private Panel CreateAppointmentCard(string time, string doctor, string reason, string date)
        {
            Panel cardPanel = new Panel();
            cardPanel.Size = new Size(flwUpcoming.Width - 10, 110);
            cardPanel.BackColor = Color.FromArgb(245, 242, 235);
            cardPanel.BorderStyle = BorderStyle.FixedSingle;
            cardPanel.Margin = new Padding(0, 5, 0, 5);

            Label lblDetails = new Label();
            lblDetails.AutoSize = true;
            lblDetails.Location = new Point(15, 10);
            lblDetails.Font = new Font("Segoe UI", 9, FontStyle.Regular);
            lblDetails.ForeColor = Color.Black;

            lblDetails.Text = $"Date:\t{date}\n" +
                              $"Time:\t{time}\n" +
                              $"Doctor:\t{doctor}\n" +
                              $"Reason:\t{reason}";

            cardPanel.Controls.Add(lblDetails);
            return cardPanel;
        }

        private void Appointment_Load(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtDate.Text = " ";
            txtTimeAppoitn.Text = " ";
            txtReason.Text = " ";
            cboDoctor.Text = " ";
        }
    }
    public class AppointmentData
    {
        public DateTime Date { get; set; }
        public string Time { get; set; }
        public string Doctor { get; set; }
        public string Reason { get; set; }
    }
   
    }
