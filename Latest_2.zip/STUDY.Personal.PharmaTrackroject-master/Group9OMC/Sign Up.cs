﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group9OMC
{
    public partial class SignUp : Form
    {
        public SignUp()
        {
            InitializeComponent();
        }

        private void lblStatusSignUp_Click(object sender, EventArgs e)
        {

        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string name_signup = txtNameSignUp.Text;
            string age = txtAge.Text;
            string email = txtEmail.Text;
            string username = txtUsernameSignUp.Text;
            string password = txtPasswordSignUp.Text;
            string PhoneNo = txtPhoneNo.Text;

            string gender = "";
            if (rdoMale.Checked)
            {
                gender = "Male";
            }
            else if (rdoFemale.Checked)
            {
                gender = "Female";
            }

           
            if (string.IsNullOrEmpty(name_signup) || string.IsNullOrEmpty(age) ||
                string.IsNullOrEmpty(email) || string.IsNullOrEmpty(username) ||
                string.IsNullOrEmpty(password) || string.IsNullOrEmpty(PhoneNo) ||
                string.IsNullOrEmpty(gender))
            {
                MessageBox.Show("Please Enter Your detail!", "Reminder", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!chkAgree.Checked)
            {
                MessageBox.Show("Please read and agree to the Privacy Policy before Sign in!", "Agreement Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            MessageBox.Show($"Registration Successful!\nWelcome {name_signup} ({gender})");
        }
        

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("PRIVACY POLICY AND TERMS OF SERVICE\r\n\r\nThis application collects personal information such as your Name, Age, Email, and Username solely for account registration and system authentication. All collected data will be strictly used to manage your account and to provide core features, including the Medication Reminder functions. Your password and account details are stored securely, and we guarantee that we do not sell, share, or disclose your personal information to any third parties. By checking the agreement box and completing this registration, you hereby consent to the collection and processing of your data as stated in this policy.", "Privacy Policy", MessageBoxButtons.OK);
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmLogIn login = new frmLogIn();
            login.ShowDialog();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtNameSignUp.Text = "";
            txtAge.Text = " ";
            txtEmail.Text = " ";
            txtUsernameSignUp.Text = " ";
            txtPasswordSignUp.Text = " ";
        }
    }
}
