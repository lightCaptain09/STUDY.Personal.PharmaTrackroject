﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group9OMC
{
    public partial class Task_Planner : Form
    {
        public Task_Planner()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnAddTask_Click(object sender, EventArgs e)
        {
            string task = txtTask.Text.Trim();
            string time = txtTime.Text.Trim();
            string note = txtNote.Text.Trim();

            if (string.IsNullOrEmpty(task) || string.IsNullOrEmpty(time) || string.IsNullOrEmpty(note))
            {
                MessageBox.Show("Please Add Your Task First!", "Reminder", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string uniqueId = Guid.NewGuid().ToString();

            Panel newTaskRow = CreateTaskRow(uniqueId, task, time, note);
            flwtask.Controls.Add(newTaskRow);
           
            txtTask.Clear();
            txtTime.Clear();
            txtNote.Clear();

            MessageBox.Show("Task successfully added to your planner!");
        }
        private Panel CreateTaskRow(string taskId, string taskName, string taskTime, string note)
        {
            Panel rowPanel = new Panel();
            rowPanel.Size = new Size(320, 65);
            rowPanel.BackColor = Color.White;
            rowPanel.Margin = new Padding(5);

            CheckBox chkTask = new CheckBox();
            chkTask.Location = new Point(10, 20);
            chkTask.Size = new Size(25, 25);

            Button btnTaskDisplay = new Button();
            btnTaskDisplay.Text = $"{taskName}   ({taskTime})\nNote: {note}";
            btnTaskDisplay.Location = new Point(45, 5);
            btnTaskDisplay.Size = new Size(220, 55);
            btnTaskDisplay.FlatStyle = FlatStyle.Flat;
            btnTaskDisplay.TextAlign = ContentAlignment.TopLeft;
            btnTaskDisplay.BackColor = Color.FromArgb(245, 245, 245);

           
            chkTask.CheckedChanged += (s, e) => {
                if (chkTask.Checked)
                {
                    btnTaskDisplay.ForeColor = Color.Gray;
                    btnTaskDisplay.Font = new Font(btnTaskDisplay.Font, FontStyle.Strikeout);
                }
                else
                {
                    btnTaskDisplay.ForeColor = Color.Black;
                    btnTaskDisplay.Font = new Font(btnTaskDisplay.Font, FontStyle.Regular);
                }
            };

           
            btnTaskDisplay.Click += (s, e) => {
                txtTask.Text = taskName;
                txtTime.Text = taskTime;
                txtNote.Text = note;
            };

            Button btnDelete = new Button();
            btnDelete.Text = "X";
            btnDelete.ForeColor = Color.Red;
            btnDelete.Font = new Font("Arial", 9, FontStyle.Bold);
            btnDelete.Location = new Point(275, 15);
            btnDelete.Size = new Size(35, 35);
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.FlatAppearance.BorderSize = 0;

           
            btnDelete.Click += (s, e) => {
                flwtask.Controls.Remove(rowPanel);
                rowPanel.Dispose();
                MessageBox.Show("Task Deleted!");
            };

            rowPanel.Controls.Add(chkTask);
            rowPanel.Controls.Add(btnTaskDisplay);
            rowPanel.Controls.Add(btnDelete);

            return rowPanel;
        }
    }
}
